<?php
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once __DIR__ . '/app/lib/env.php';
if (function_exists('load_env')) {
    load_env(__DIR__ . '/.env');
}
require_once __DIR__ . '/app/lib/db.php';

try {
    $pdo = db();
    echo "Connected to database successfully.<br>";

    // 1. Truncate table
    $pdo->exec("TRUNCATE TABLE passwords");
    echo "Table 'passwords' truncated.<br>";

    // 2. Prepare statements
    $stmt = $pdo->prepare("INSERT INTO passwords (role, pass_hash) VALUES (?, ?)");

    // 3. User data
    $users = [
        'OFFICER' => 'password',
        'FINANCE' => 'password',
        'ADMIN' => 'password',
        'AUDIT' => 'password'
    ];

    // 4. Insert
    foreach ($users as $role => $pass) {
        $hash = password_hash($pass, PASSWORD_DEFAULT);
        $stmt->execute([$role, $hash]);
        echo "Inserted role: <strong>$role</strong> with new hash.<br>";
    }

    echo "<br><strong>Password reset complete!</strong><br>";
    echo "All passwords have been reset to: <code>password</code><br>";
    echo "You can now try to login.";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage();
}
