<?php
$users = [
    'OFFICER' => 'password',
    'FINANCE' => 'password',
    'ADMIN' => 'password',
    'AUDIT' => 'password'
];

echo "truncate table passwords;\n";
echo "INSERT INTO passwords (role, pass_hash) VALUES\n";
$values = [];
foreach ($users as $role => $pass) {
    $hash = password_hash($pass, PASSWORD_DEFAULT);
    // Escape single quotes just in case, though these specific passwords don't have them
    $values[] = "('$role', '$hash')";
}
echo implode(",\n", $values) . ";\n";
