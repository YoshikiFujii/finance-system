truncate table passwords;
INSERT INTO passwords (role, pass_hash) VALUES
('OFFICER', '$2y$12$6TxXEhlzWiJqLY816jT3U.VuXsUu8JCUVyOW2Sw.svud.zswW7LWm'),
('FINANCE', '$2y$12$Vj.2HObgX9roHTVBWwxLvenxQl7ha9SyD6fW5HGVlXu7EDcrQfEO.'),
('ADMIN', '$2y$12$Vq6patap0fVL2yPVMlUz.uYnlFZq7nopaRQff2YMjMr2FH6dbD70i'),
('AUDIT', '$2y$12$Kzgv79LdEy7fYYNkkGmQLe.cVCjots2s5EE5eEn4WYZKmZcZTfH6q');
