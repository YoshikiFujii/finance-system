-- Lotus Purchase Request Backup
-- Generated: 2025-10-09 22:53:09
-- Database: if0_40099794_lotus
-- Tables: requests, request_items, receipts, departments, members, events

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS `requests`;
CREATE TABLE `requests` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `request_no` varchar(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `department_id` bigint(20) NOT NULL,
  `submitted_at` datetime NOT NULL,
  `summary` varchar(255) NOT NULL,
  `expects_network` enum('NONE','CONVENIENCE','BANK_TRANSFER') NOT NULL DEFAULT 'NONE',
  `state` enum('NEW','ACCEPTED','REJECTED','CASH_GIVEN','COLLECTED','RECEIPT_DONE','TRANSFERRED','FINALIZED') NOT NULL DEFAULT 'NEW',
  `expected_total` decimal(12,2) DEFAULT NULL,
  `cash_given` decimal(12,2) DEFAULT NULL,
  `diff_amount` decimal(12,2) DEFAULT NULL,
  `excel_path` varchar(255) DEFAULT NULL,
  `notes` mediumtext DEFAULT NULL,
  `rejected_reason` varchar(255) DEFAULT NULL,
  `bank_name` varchar(100) DEFAULT NULL,
  `branch_name` varchar(100) DEFAULT NULL,
  `account_type` varchar(20) DEFAULT NULL,
  `account_number` varchar(20) DEFAULT NULL,
  `account_holder` varchar(100) DEFAULT NULL,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_at` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `request_no` (`request_no`),
  KEY `member_id` (`member_id`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `requests` (`id`, `request_no`, `member_id`, `department_id`, `submitted_at`, `summary`, `expects_network`, `state`, `expected_total`, `cash_given`, `diff_amount`, `excel_path`, `notes`, `rejected_reason`, `bank_name`, `branch_name`, `account_type`, `account_number`, `account_holder`, `created_at`, `updated_at`) VALUES
('19', 'LOCK', '101', '45', '2025-10-09 21:36:38', 'テスト購入', 'NONE', 'FINALIZED', NULL, '2000.00', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-10-09 18:36:38', '2025-10-09 18:37:38');

DROP TABLE IF EXISTS `request_items`;
CREATE TABLE `request_items` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `request_id` bigint(20) NOT NULL,
  `purpose` varchar(255) NOT NULL,
  `amount` decimal(12,2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- Table request_items is empty

DROP TABLE IF EXISTS `receipts`;
CREATE TABLE `receipts` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `request_id` bigint(20) NOT NULL,
  `kind` enum('RECEIPT','INVOICE','TRANSFER_SLIP','PAYMENT_SLIP') NOT NULL,
  `total` decimal(12,2) NOT NULL,
  `change_returned` decimal(12,2) DEFAULT 0.00,
  `file_path` varchar(255) DEFAULT NULL,
  `taken_at` datetime NOT NULL,
  `memo` varchar(255) DEFAULT NULL,
  `event_id` bigint(20) DEFAULT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `payer` varchar(255) DEFAULT NULL,
  `receipt_date` date DEFAULT NULL,
  `is_completed` tinyint(1) DEFAULT 0,
  `receipt_no` varchar(20) DEFAULT NULL,
  `purpose` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `request_id` (`request_id`)
) ENGINE=MyISAM AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `receipts` (`id`, `request_id`, `kind`, `total`, `change_returned`, `file_path`, `taken_at`, `memo`, `event_id`, `subject`, `payer`, `receipt_date`, `is_completed`, `receipt_no`, `purpose`) VALUES
('23', '19', 'RECEIPT', '1800.00', '0.00', NULL, '2025-10-10 00:00:00', NULL, '10', 'い', '岩本 利通', '2025-10-10', '1', 'LOCK-1', '備品購入');

DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `departments` (`id`, `name`, `is_active`, `created_at`) VALUES
('45', '三役', '1', '2025-10-06 21:06:21'),
('46', '総務', '1', '2025-10-06 21:06:21'),
('47', '財務', '1', '2025-10-06 21:06:21'),
('48', '風紀', '1', '2025-10-06 21:06:21'),
('49', '厚生', '1', '2025-10-06 21:06:21'),
('50', '企画', '1', '2025-10-06 21:06:21'),
('51', '渉外広報', '1', '2025-10-06 21:06:21'),
('52', 'FM', '1', '2025-10-06 21:06:21');

DROP TABLE IF EXISTS `members`;
CREATE TABLE `members` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `department_id` bigint(20) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `department_id` (`department_id`)
) ENGINE=MyISAM AUTO_INCREMENT=167 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `members` (`id`, `name`, `department_id`, `is_active`, `created_at`) VALUES
('100', '向井 瑛志', '45', '1', '2025-10-06 21:06:21'),
('101', '岩本 利通', '45', '1', '2025-10-06 21:06:21'),
('102', '横山 楓人', '45', '1', '2025-10-06 21:06:21'),
('103', '青山 和瑚', '45', '1', '2025-10-06 21:06:21'),
('104', '小林 羚偉', '45', '1', '2025-10-06 21:06:21'),
('105', '渡辺 美怜', '45', '1', '2025-10-06 21:06:21'),
('106', '吉田 悠人', '46', '1', '2025-10-06 21:06:21'),
('107', '小泉 杏奈', '46', '1', '2025-10-06 21:06:21'),
('108', '藤井 義己', '47', '1', '2025-10-06 21:06:21'),
('109', '庄子 夢唯', '47', '1', '2025-10-06 21:06:21'),
('110', '姿 颯磨', '48', '1', '2025-10-06 21:06:21'),
('111', '西澤 凛', '48', '1', '2025-10-06 21:06:21'),
('112', '池田 陸人', '49', '1', '2025-10-06 21:06:21'),
('113', '小川 仁瑚', '49', '1', '2025-10-06 21:06:21'),
('114', '谷村 光紀', '50', '1', '2025-10-06 21:06:21'),
('115', '後藤 すみれ', '50', '1', '2025-10-06 21:06:21'),
('116', '千葉 太陽', '51', '1', '2025-10-06 21:06:21'),
('117', '藤田 はな', '51', '1', '2025-10-06 21:06:21'),
('118', '田中 佑哉', '46', '1', '2025-10-06 21:06:21'),
('119', '大内 煌太郎', '46', '1', '2025-10-06 21:06:21'),
('120', '大輪 駿斗', '46', '1', '2025-10-06 21:06:21'),
('121', '菊池 康生', '46', '1', '2025-10-06 21:06:21'),
('122', '下醉尾 朔也', '46', '1', '2025-10-06 21:06:21'),
('123', '荻原 悠輔', '46', '1', '2025-10-06 21:06:21'),
('124', '菊池 あかり', '46', '1', '2025-10-06 21:06:21'),
('125', '竹内 月渚', '46', '1', '2025-10-06 21:06:21'),
('126', '今村 尚輝', '47', '1', '2025-10-06 21:06:21'),
('127', '島 凱人', '47', '1', '2025-10-06 21:06:21'),
('128', '千本木 匠', '47', '1', '2025-10-06 21:06:21'),
('129', '平 あかり', '47', '1', '2025-10-06 21:06:21'),
('130', '牧野 真歩', '47', '1', '2025-10-06 21:06:21'),
('131', '池田 翼', '48', '1', '2025-10-06 21:06:21'),
('132', '澁谷 應介', '48', '1', '2025-10-06 21:06:21'),
('133', '室井 優希', '48', '1', '2025-10-06 21:06:21'),
('134', '小野寺 幸', '48', '1', '2025-10-06 21:06:21'),
('135', '福原 真昊', '48', '1', '2025-10-06 21:06:21'),
('136', '小竹 獅禅', '49', '1', '2025-10-06 21:06:21'),
('137', '櫻井 悠真', '49', '1', '2025-10-06 21:06:21'),
('138', '笹島 啓介', '49', '1', '2025-10-06 21:06:21'),
('139', '眞壁 斗棋', '49', '1', '2025-10-06 21:06:21'),
('140', '田名網 脩人', '49', '1', '2025-10-06 21:06:21'),
('141', '松本 貴沙', '49', '1', '2025-10-06 21:06:21'),
('142', '佐藤 心紅', '49', '1', '2025-10-06 21:06:21'),
('143', '網田 遼介', '50', '1', '2025-10-06 21:06:21'),
('144', '斉藤 大樹', '50', '1', '2025-10-06 21:06:21'),
('145', '本間幸弥', '50', '1', '2025-10-06 21:06:21'),
('146', '小野 竜弥', '50', '1', '2025-10-06 21:06:21'),
('147', '礒野 蓮', '50', '1', '2025-10-06 21:06:21'),
('148', '林 夏漣', '50', '1', '2025-10-06 21:06:21'),
('149', '白川 裕菜', '50', '1', '2025-10-06 21:06:21'),
('150', '比嘉 真愛', '50', '1', '2025-10-06 21:06:21'),
('151', '阿部 宏祐', '51', '1', '2025-10-06 21:06:21'),
('152', '羽山 俊希', '51', '1', '2025-10-06 21:06:21'),
('153', '髙橋 芽依', '51', '1', '2025-10-06 21:06:21'),
('154', '塩原 沙季', '51', '1', '2025-10-06 21:06:21'),
('155', '島崎 誠大', '52', '1', '2025-10-06 21:06:21'),
('156', '澤田 誠路', '52', '1', '2025-10-06 21:06:21'),
('157', '間中 宏尚', '52', '1', '2025-10-06 21:06:21'),
('158', '野村 柊斗', '52', '1', '2025-10-06 21:06:21'),
('159', '伊藤 一成', '52', '1', '2025-10-06 21:06:21'),
('160', '圖師 龍杜', '52', '1', '2025-10-06 21:06:21'),
('161', '米澤 慧師', '52', '1', '2025-10-06 21:06:21'),
('162', '伊藤 凜', '52', '1', '2025-10-06 21:06:21'),
('163', '清水 心愛', '52', '1', '2025-10-06 21:06:21'),
('164', '髙橋 虹光', '52', '1', '2025-10-06 21:06:21'),
('165', '瀬尾 真央', '52', '1', '2025-10-06 21:06:21'),
('166', '比屋根 佳歩', '52', '1', '2025-10-06 21:06:21');

DROP TABLE IF EXISTS `events`;
CREATE TABLE `events` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `events` (`id`, `name`, `is_active`, `created_at`) VALUES
('10', 'てすと', '1', '2025-10-08 20:40:42');

SET FOREIGN_KEY_CHECKS = 1;
